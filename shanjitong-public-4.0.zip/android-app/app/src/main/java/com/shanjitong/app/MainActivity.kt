package com.shanjitong.app
import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
 private lateinit var webView: WebView
 private val WEBSITE_URL = "https://YOUR-SHANJITONG-DOMAIN.onrender.com/"
 @SuppressLint("SetJavaScriptEnabled")
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  webView=WebView(this); setContentView(webView)
  webView.settings.javaScriptEnabled=true
  webView.settings.domStorageEnabled=true
  webView.settings.allowContentAccess=true
  webView.settings.allowFileAccess=true
  webView.webViewClient=WebViewClient()
  webView.webChromeClient=WebChromeClient()
  webView.loadUrl(WEBSITE_URL)
 }
 override fun onBackPressed(){if(webView.canGoBack())webView.goBack()else super.onBackPressed()}
 override fun onDestroy(){webView.destroy();super.onDestroy()}
}
