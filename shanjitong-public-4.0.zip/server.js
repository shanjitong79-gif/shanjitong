const express=require("express");
const multer=require("multer");
const crypto=require("crypto");
const {Pool}=require("pg");
const path=require("path");

const app=express();
const PORT=process.env.PORT||10000;
const ADMIN_USER=process.env.ADMIN_USER||"admin";
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||"ChangeMe_123!";
const SESSION_SECRET=process.env.SESSION_SECRET||crypto.randomBytes(32).toString("hex");

const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL?{rejectUnauthorized:false}:false});
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024}});

app.use(express.json({limit:"8mb"}));
app.use(express.urlencoded({extended:true,limit:"8mb"}));

function sign(v){return crypto.createHmac("sha256",SESSION_SECRET).update(v).digest("hex")}
function token(){const p=Buffer.from(JSON.stringify({u:ADMIN_USER,t:Date.now()})).toString("base64url");return p+"."+sign(p)}
function auth(req,res,next){
  const c=req.headers.cookie||"";
  const m=c.match(/sj_auth=([^;]+)/);
  if(!m)return res.status(401).json({error:"未登录"});
  const [p,s]=m[1].split(".");
  if(!p||!s||!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(sign(p))))return res.status(401).json({error:"未登录"});
  try{const x=JSON.parse(Buffer.from(p,"base64url").toString());if(x.u!==ADMIN_USER)throw 0;req.admin=x.u;next()}catch{res.status(401).json({error:"未登录"})}
}
async function init(){
 await pool.query(`CREATE TABLE IF NOT EXISTS news(
  id BIGSERIAL PRIMARY KEY,title TEXT NOT NULL,summary TEXT DEFAULT '',content TEXT NOT NULL,
  image TEXT DEFAULT '',status TEXT NOT NULL DEFAULT 'published',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
}
app.get("/api/health",(req,res)=>res.json({ok:true,service:"shanjitong",version:"4.0.0"}));
app.get("/api/news",async(req,res)=>{
 try{const r=await pool.query("SELECT id,title,summary,content,image,status,created_at,updated_at FROM news WHERE status='published' ORDER BY created_at DESC");res.json(r.rows)}
 catch(e){res.status(500).json({error:"数据库错误"})}
});
app.get("/api/news/:id",async(req,res)=>{
 try{const r=await pool.query("SELECT * FROM news WHERE id=$1 AND status='published'",[req.params.id]);if(!r.rows[0])return res.status(404).json({error:"不存在"});res.json(r.rows[0])}
 catch(e){res.status(500).json({error:"数据库错误"})}
});
app.post("/api/login",(req,res)=>{
 const {username,password}=req.body||{};
 if(username===ADMIN_USER&&password===ADMIN_PASSWORD){
   res.setHeader("Set-Cookie",`sj_auth=${token()}; Path=/; HttpOnly; SameSite=Lax; Max-Age=86400; Secure`);
   return res.json({ok:true,user:ADMIN_USER});
 }
 res.status(401).json({error:"账号或密码错误"});
});
app.post("/api/logout",(req,res)=>{res.setHeader("Set-Cookie","sj_auth=; Path=/; HttpOnly; Max-Age=0; SameSite=Lax; Secure");res.json({ok:true})});
app.get("/api/me",auth,(req,res)=>res.json({ok:true,user:req.admin}));
app.get("/api/admin/news",auth,async(req,res)=>{
 try{const r=await pool.query("SELECT * FROM news ORDER BY created_at DESC");res.json(r.rows)}
 catch(e){res.status(500).json({error:"数据库错误"})}
});
app.post("/api/admin/news",auth,async(req,res)=>{
 const {title,summary="",content,image="",status="published"}=req.body||{};
 if(!title||!content)return res.status(400).json({error:"标题和正文不能为空"});
 try{const r=await pool.query("INSERT INTO news(title,summary,content,image,status) VALUES($1,$2,$3,$4,$5) RETURNING *",[title,summary,content,image,status]);res.json(r.rows[0])}
 catch(e){res.status(500).json({error:"保存失败"})}
});
app.put("/api/admin/news/:id",auth,async(req,res)=>{
 const {title,summary="",content,image="",status="published"}=req.body||{};
 try{const r=await pool.query("UPDATE news SET title=$1,summary=$2,content=$3,image=$4,status=$5,updated_at=NOW() WHERE id=$6 RETURNING *",[title,summary,content,image,status,req.params.id]);if(!r.rows[0])return res.status(404).json({error:"不存在"});res.json(r.rows[0])}
 catch(e){res.status(500).json({error:"更新失败"})}
});
app.delete("/api/admin/news/:id",auth,async(req,res)=>{
 try{await pool.query("DELETE FROM news WHERE id=$1",[req.params.id]);res.json({ok:true})}
 catch(e){res.status(500).json({error:"删除失败"})}
});
app.post("/api/admin/upload",auth,upload.single("image"),async(req,res)=>{
 if(!req.file)return res.status(400).json({error:"没有图片"});
 if(!/^image\/(jpeg|png|webp|gif)$/.test(req.file.mimetype))return res.status(400).json({error:"仅支持 jpg/png/webp/gif"});
 const data=`data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
 res.json({image:data});
});
app.use(express.static(path.join(__dirname,"public")));
app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.use((req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

init().then(()=>app.listen(PORT,"0.0.0.0",()=>console.log(`shanjitong listening on ${PORT}`))).catch(e=>{console.error(e);process.exit(1)});
