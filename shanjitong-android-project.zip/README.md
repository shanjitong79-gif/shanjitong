# shanjitong Android 工程

完整 Android Studio 工程。官网和本地新闻后台内置在 APK 中，不需要服务器、Node.js 或 Termux。

## 打开
用 Android Studio 打开项目根目录，等待 Gradle 同步，然后运行 app。

## 生成 APK
Android Studio → Build → Build APK(s)。
APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 后台
默认账号：admin
默认密码：ChangeMe_123!

新闻数据保存在本机 WebView localStorage。以后接入服务器时，可以把数据层替换成公网 API。
