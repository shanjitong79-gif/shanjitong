plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.shanjitong.app"; compileSdk=35
    defaultConfig { applicationId="com.shanjitong.app"; minSdk=23; targetSdk=35; versionCode=1; versionName="1.0.0" }
    buildTypes { release { isMinifyEnabled=false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro") } }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
