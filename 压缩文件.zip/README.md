# 善鸡通 Android 一键 APK 工程

这是可直接放进 GitHub 的 Android 工程，并内置 GitHub Actions 自动编译 APK。

## 手机上生成 APK

1. 将整个工程内容上传到 GitHub 仓库根目录。
2. 打开 GitHub → Actions → `Build Android APK`。
3. 点 `Run workflow`。
4. 在 `公网网站地址` 填写 Render 部署后的网址，例如 `https://shanjitong.onrender.com/`。
5. 等待构建完成。
6. 打开本次运行 → Artifacts → `shanjitong-apk`，下载 `app-debug.apk`。

## 自动构建

每次向 main 推送代码也会自动执行构建。若尚未配置公网地址，手动 Run workflow 时填写真实地址即可。
