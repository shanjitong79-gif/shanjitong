const express=require("express");
const session=require("express-session");
const Database=require("better-sqlite3");
const multer=require("multer");
const path=require("path"), fs=require("fs"), crypto=require("crypto");

const app=express();
const PORT=process.env.PORT||3000;
const ADMIN_USER=process.env.ADMIN_USER||"admin";
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||"ChangeMe_123!";
const SESSION_SECRET=process.env.SESSION_SECRET||crypto.randomBytes(32).toString("hex");

const root=__dirname, publicDir=path.join(root,"public"), uploadDir=path.join(publicDir,"uploads");
fs.mkdirSync(uploadDir,{recursive:true});

const db=new Database(path.join(root,"news.db"));
db.pragma("journal_mode = WAL");
db.exec(`CREATE TABLE IF NOT EXISTS news(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 summary TEXT DEFAULT '',
 content TEXT NOT NULL,
 image TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'published',
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
)`);

const upload=multer({
 destination:uploadDir,
 limits:{fileSize:5*1024*1024},
 fileFilter:(req,file,cb)=>{
   const ok=/^image\/(jpeg|png|webp|gif)$/i.test(file.mimetype);
   cb(ok?null:new Error("仅支持 JPG/PNG/WebP/GIF 图片"),ok);
 }
});

app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({extended:true}));
app.use(session({
 secret:SESSION_SECRET,
 resave:false,
 saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}
}));
app.use(express.static(publicDir));

function auth(req,res,next){
 if(req.session.user===ADMIN_USER) return next();
 res.status(401).json({error:"未登录"});
}
function now(){return new Date().toISOString();}
function clean(n){return {
 id:n.id,title:n.title,summary:n.summary,content:n.content,image:n.image,
 status:n.status,created_at:n.created_at,updated_at:n.updated_at
};}

app.get("/api/news",(req,res)=>{
 const rows=db.prepare("SELECT * FROM news WHERE status='published' ORDER BY id DESC").all();
 res.json(rows.map(clean));
});
app.get("/api/news/:id",(req,res)=>{
 const n=db.prepare("SELECT * FROM news WHERE id=?").get(req.params.id);
 if(!n || (n.status!=="published" && req.session.user!==ADMIN_USER)) return res.status(404).json({error:"文章不存在"});
 res.json(clean(n));
});
app.post("/api/login",(req,res)=>{
 const {username,password}=req.body||{};
 if(username===ADMIN_USER && password===ADMIN_PASSWORD){
   req.session.user=ADMIN_USER; return res.json({ok:true});
 }
 res.status(401).json({error:"账号或密码错误"});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json({loggedIn:req.session.user===ADMIN_USER,username:req.session.user||null}));

app.get("/api/admin/news",auth,(req,res)=>{
 res.json(db.prepare("SELECT * FROM news ORDER BY id DESC").all().map(clean));
});
app.post("/api/admin/news",auth,(req,res)=>{
 const {title,summary="",content,status="published",image=""}=req.body||{};
 if(!title||!content) return res.status(400).json({error:"标题和正文不能为空"});
 const t=now();
 const info=db.prepare("INSERT INTO news(title,summary,content,image,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)")
 .run(title,summary,content,image,status,t,t);
 res.json(clean(db.prepare("SELECT * FROM news WHERE id=?").get(info.lastInsertRowid)));
});
app.put("/api/admin/news/:id",auth,(req,res)=>{
 const old=db.prepare("SELECT * FROM news WHERE id=?").get(req.params.id);
 if(!old) return res.status(404).json({error:"文章不存在"});
 const {title=old.title,summary=old.summary,content=old.content,status=old.status,image=old.image}=req.body||{};
 db.prepare("UPDATE news SET title=?,summary=?,content=?,image=?,status=?,updated_at=? WHERE id=?")
 .run(title,summary,content,image,status,now(),req.params.id);
 res.json(clean(db.prepare("SELECT * FROM news WHERE id=?").get(req.params.id)));
});
app.delete("/api/admin/news/:id",auth,(req,res)=>{
 db.prepare("DELETE FROM news WHERE id=?").run(req.params.id);
 res.json({ok:true});
});
app.post("/api/admin/upload",auth,upload.single("image"),(req,res)=>{
 if(!req.file) return res.status(400).json({error:"请选择图片"});
 res.json({url:"/uploads/"+req.file.filename});
});

app.get("/admin",(req,res)=>res.sendFile(path.join(publicDir,"admin.html")));
app.use((err,req,res,next)=>{
 if(err) return res.status(400).json({error:err.message||"请求失败"});
 next();
});

app.listen(PORT,"0.0.0.0",()=>console.log(`shanjitong running on http://0.0.0.0:${PORT}`));
