# shanjitong 真实新闻发布系统

## 功能
- SQLite 持久化新闻数据
- 管理员登录
- 新增新闻
- 编辑新闻
- 删除新闻
- 草稿 / 立即发布
- 前台自动读取已发布新闻
- 新闻详情页
- 基础输入校验与 Session 登录

## 启动

需要 Node.js 18+。

```bash
npm install
npm start
```

浏览器打开：
- 网站新闻中心：http://localhost:3000/
- 管理后台：http://localhost:3000/admin.html

## 默认管理员
账号：`admin`
密码：`ChangeMe_123!`

正式部署前务必修改环境变量：

Linux/macOS:
```bash
ADMIN_USER=你的账号 ADMIN_PASSWORD=你的强密码 SESSION_SECRET=随机长字符串 npm start
```

Windows PowerShell:
```powershell
$env:ADMIN_USER="你的账号"
$env:ADMIN_PASSWORD="你的强密码"
$env:SESSION_SECRET="随机长字符串"
npm start
```

新闻数据库会自动生成 `news.db`，无需手动建表。

## 生产环境建议
- 使用 HTTPS
- 修改默认管理员密码
- 设置稳定的 SESSION_SECRET
- 使用反向代理（如 Nginx）
- 定期备份 news.db
- 如果需要图片上传，可继续接入对象存储
