package com.shanjitong.ai
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
class MainActivity:Activity(){override fun onCreate(b:Bundle?){super.onCreate(b);val w=WebView(this);w.webViewClient=WebViewClient();w.settings.javaScriptEnabled=true;w.settings.domStorageEnabled=true;w.loadUrl("https://YOUR-SHANJITONG-AI-DOMAIN.onrender.com/");setContentView(w)}}
