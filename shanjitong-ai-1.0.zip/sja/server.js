import express from 'express'; import cors from 'cors';
const app=express(); app.use(cors()); app.use(express.json({limit:'2mb'})); app.use(express.static('public'));
const PORT=process.env.PORT||3000, URL=process.env.AI_API_URL||'', KEY=process.env.AI_API_KEY||'', MODEL=process.env.AI_MODEL||'';
app.get('/api/health',(q,s)=>s.json({ok:true,name:'善鸡通 AI',version:'1.0.0'}));
app.post('/api/chat',async(q,s)=>{const m=Array.isArray(q.body?.messages)?q.body.messages:[]; if(!m.length)return s.status(400).json({error:'messages required'}); if(!URL||!KEY)return s.json({reply:'善鸡通 AI 1.0 已启动。请配置 AI_API_URL、AI_API_KEY 和 AI_MODEL 后连接 AI 模型。'}); try{const r=await fetch(URL,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${KEY}`},body:JSON.stringify({model:MODEL,messages:m,temperature:.7})});const d=await r.json();if(!r.ok)return s.status(r.status).json({error:d?.error?.message||'AI provider error'});s.json({reply:d?.choices?.[0]?.message?.content||'AI 没有返回内容。'});}catch(e){s.status(500).json({error:'AI service unavailable'})}});
app.listen(PORT,'0.0.0.0',()=>console.log(`善鸡通 AI listening on ${PORT}`));
