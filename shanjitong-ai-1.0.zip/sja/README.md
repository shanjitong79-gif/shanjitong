# 善鸡通 AI 1.0
手机优先、Windows 风格的个人 AI 助手。

部署后配置 AI_API_URL、AI_API_KEY、AI_MODEL。AI_API_URL 使用兼容 OpenAI Chat Completions 的接口即可。

包含 Node/Express 后端、Web 聊天界面、Render 配置和 Android App 工程。
