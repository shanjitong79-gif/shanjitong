import express from 'express';
import cors from 'cors';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const AI_API_URL = process.env.AI_API_URL || '';
const AI_API_KEY = process.env.AI_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || '';
const AI_SYSTEM_PROMPT = process.env.AI_SYSTEM_PROMPT ||
  '你是善鸡通 AI，一个友好、准确、简洁的中文 AI 助手。回答问题时尽量直接、有条理；不确定时明确说明。';

app.disable('x-powered-by');
app.use(cors({ origin: true, credentials: false }));
app.use(express.json({ limit: '1mb' }));
app.use(express.static('public', { extensions: ['html'] }));

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    name: '善鸡通 AI',
    version: '1.0.0',
    aiConfigured: Boolean(AI_API_URL && AI_API_KEY && AI_MODEL)
  });
});

app.post('/api/chat', async (req, res) => {
  const incoming = Array.isArray(req.body?.messages) ? req.body.messages : [];
  const messages = incoming
    .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .slice(-30)
    .map(m => ({ role: m.role, content: m.content.slice(0, 12000) }));

  if (!messages.length) return res.status(400).json({ error: '请输入消息。' });
  if (messages[messages.length - 1].role !== 'user') {
    return res.status(400).json({ error: '最后一条消息必须来自用户。' });
  }
  if (!AI_API_URL || !AI_API_KEY || !AI_MODEL) {
    return res.status(503).json({
      error: 'AI 尚未配置。请在服务器环境变量中设置 AI_API_URL、AI_API_KEY 和 AI_MODEL。'
    });
  }

  try {
    const upstream = await fetch(AI_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${AI_API_KEY}`
      },
      body: JSON.stringify({
        model: AI_MODEL,
        messages: [{ role: 'system', content: AI_SYSTEM_PROMPT }, ...messages],
        temperature: 0.7
      })
    });

    const raw = await upstream.text();
    let data = {};
    try { data = JSON.parse(raw); } catch {}

    if (!upstream.ok) {
      const detail = data?.error?.message || data?.message || `AI 服务返回 HTTP ${upstream.status}`;
      return res.status(502).json({ error: detail });
    }

    const reply = data?.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: 'AI 服务没有返回有效内容。' });
    return res.json({ reply });
  } catch (error) {
    console.error('AI request failed:', error?.message || error);
    return res.status(502).json({ error: '无法连接 AI 服务，请检查 AI_API_URL 和网络设置。' });
  }
});

app.get('*', (_req, res) => res.sendFile(process.cwd() + '/public/index.html'));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`善鸡通 AI Web 1.0 listening on port ${PORT}`);
});
