# 善鸡通 AI Web 1.0

手机浏览器 → 善鸡通 AI 网站 → AI 后端 → AI 模型。

## 运行

```bash
npm install
npm start
```

打开 `http://localhost:3000`。

## 配置 AI

设置三个服务器环境变量：

- `AI_API_URL`：OpenAI-compatible Chat Completions 接口地址
- `AI_API_KEY`：AI 服务 API Key
- `AI_MODEL`：AI 模型名称

可参考 `.env.example`。

## Render 部署

本项目已经包含 `render.yaml`。把整个目录上传到 GitHub 后，在 Render 创建 Web Service 并使用该仓库即可。部署时配置三个 AI 环境变量。

## API

- `GET /api/health`：检查网站和 AI 配置状态
- `POST /api/chat`：AI 对话接口

API Key 只在服务器端使用，浏览器不会收到 Key。
