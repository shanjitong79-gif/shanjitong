# shanjitong 部署说明

一个 YouTube 风格的视频站：邮箱注册登录、上传视频、点赞、评论、订阅、搜索、热门。
前端是纯静态文件（不需要构建），后端用 Supabase（登录 + 数据库 + 视频存储）。

## 一、创建 Supabase 项目（约 5 分钟）

1. 打开 https://supabase.com ，注册并点 New project（区域选离用户近的）。
2. 左侧 **SQL Editor** → New query，把 `supabase/schema.sql` 全部内容粘贴进去，点 Run。
   这一步会建好数据表、权限规则和名为 `videos` 的存储桶。
3. 左侧 **Project Settings → API**，复制两项：
   - Project URL
   - anon public key
4. 打开本目录的 `config.js`，把这两项填进去。

## 二、登录设置

在 **Authentication** 里：

- **Providers → Email**：保持开启。想让用户注册后直接能用，可以关掉 "Confirm email"；
  保持开启则用户要先点邮件里的确认链接（正式运营建议开启，并在
  **Authentication → SMTP Settings** 配置自己的发信服务，自带邮件服务有发送频率限制）。
- **URL Configuration**：把 Site URL 改成你的正式网址（部署后再改）。

## 三、部署到公网

任选一个静态托管，把整个目录当成静态站点上传即可，**不需要构建命令**：

- **Vercel**：注册后 Add New → Project，导入 GitHub 仓库（或用 `vercel` 命令行部署本目录）。
  Framework 选 Other，Build Command 留空，Output Directory 留空（根目录）。
- **Cloudflare Pages / Netlify**：同理，选择目录部署即可。

部署完成会得到一个 `xxx.vercel.app` 之类的网址；在托管后台的 Domains 里可以绑定自己的域名。
别忘了回到 Supabase 的 URL Configuration，把 Site URL 改成最终域名。

## 四、本地试跑

浏览器直接双击 index.html 不行（模块加载需要 http）。在本目录运行：

    python3 -m http.server 8080

然后访问 http://localhost:8080 。

## 五、需要知道的限制

- Supabase 免费版单个文件上限 50MB，存储和流量也有额度（以官网为准）。
  要支持更大的视频：升级 Supabase 套餐并同时修改 `config.js` 的 `MAX_UPLOAD_MB`
  和 `schema.sql` 里 bucket 的 `file_size_limit`；
  或改用 Cloudflare R2 / Mux / Bunny Stream 这类视频存储与转码服务。
- 视频不做转码，直接播放上传的原文件。浏览器对格式的兼容性：mp4(H.264) 最稳；
  手机录的 mov 在部分浏览器里可能无法播放，建议用户上传 mp4。
- 播放量是简单计数（每次打开视频页 +1），没有防刷。
- **公开平台要自己负责内容**：用户上传的内容需要审核、举报和删除机制，
  这一版没有做。正式开放前建议至少加上举报按钮和管理员后台。
- 如果面向中国大陆用户：使用大陆服务器和域名需要 ICP 备案；使用境外服务（如 Supabase、Vercel）
  无需备案，但大陆访问速度和稳定性可能不理想。

## 文件结构

    index.html            全部前端页面和逻辑
    config.js             Supabase 地址和密钥（需要你填写）
    supabase/schema.sql   数据库结构、权限规则、存储桶
