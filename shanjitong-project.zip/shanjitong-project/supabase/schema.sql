-- shanjitong 数据库结构：在 Supabase 的 SQL Editor 里整段运行一次即可

-- ========== 表 ==========
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 20),
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 60),
  description text not null default '' check (char_length(description) <= 500),
  tag text not null default '日常',
  video_path text not null,
  thumb_path text,
  duration integer not null default 0,
  view_count integer not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists videos_created_idx on public.videos (created_at desc);
create index if not exists videos_user_idx on public.videos (user_id);

create table if not exists public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, video_id)
);

create table if not exists public.subscriptions (
  subscriber_id uuid not null references public.profiles(id) on delete cascade,
  channel_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (subscriber_id, channel_id),
  check (subscriber_id <> channel_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 200),
  created_at timestamptz not null default now()
);
create index if not exists comments_video_idx on public.comments (video_id, created_at desc);

-- ========== 注册时自动创建个人资料 ==========
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(
      nullif(left(trim(coalesce(new.raw_user_meta_data->>'display_name', '')), 20), ''),
      left(split_part(new.email, '@', 1), 20)
    )
  );
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ========== 播放量 +1（任何人可调用） ==========
create or replace function public.increment_view(vid uuid)
returns void language sql security definer set search_path = public as $$
  update public.videos set view_count = view_count + 1 where id = vid;
$$;
grant execute on function public.increment_view(uuid) to anon, authenticated;

-- ========== 行级权限（RLS）：所有人可看，只有本人能改自己的数据 ==========
alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.likes enable row level security;
alter table public.subscriptions enable row level security;
alter table public.comments enable row level security;

drop policy if exists "profiles_read" on public.profiles;
create policy "profiles_read" on public.profiles for select using (true);
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "videos_read" on public.videos;
create policy "videos_read" on public.videos for select using (true);
drop policy if exists "videos_insert_own" on public.videos;
create policy "videos_insert_own" on public.videos for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "videos_update_own" on public.videos;
create policy "videos_update_own" on public.videos for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "videos_delete_own" on public.videos;
create policy "videos_delete_own" on public.videos for delete to authenticated using (user_id = auth.uid());

drop policy if exists "likes_read" on public.likes;
create policy "likes_read" on public.likes for select using (true);
drop policy if exists "likes_insert_own" on public.likes;
create policy "likes_insert_own" on public.likes for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "likes_delete_own" on public.likes;
create policy "likes_delete_own" on public.likes for delete to authenticated using (user_id = auth.uid());

drop policy if exists "subs_read" on public.subscriptions;
create policy "subs_read" on public.subscriptions for select using (true);
drop policy if exists "subs_insert_own" on public.subscriptions;
create policy "subs_insert_own" on public.subscriptions for insert to authenticated with check (subscriber_id = auth.uid());
drop policy if exists "subs_delete_own" on public.subscriptions;
create policy "subs_delete_own" on public.subscriptions for delete to authenticated using (subscriber_id = auth.uid());

drop policy if exists "comments_read" on public.comments;
create policy "comments_read" on public.comments for select using (true);
drop policy if exists "comments_insert_own" on public.comments;
create policy "comments_insert_own" on public.comments for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "comments_delete_own" on public.comments;
create policy "comments_delete_own" on public.comments for delete to authenticated using (user_id = auth.uid());

-- ========== 视频存储桶 ==========
-- file_size_limit 单位是字节：52428800 = 50MB（免费版上限）
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('videos', 'videos', true, 52428800, array['video/mp4', 'video/webm', 'video/quicktime', 'image/jpeg'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- 文件路径格式：<用户id>/<文件名>，只有本人能往自己的文件夹上传、删除
drop policy if exists "videos_upload_own" on storage.objects;
create policy "videos_upload_own" on storage.objects for insert to authenticated
  with check (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "videos_delete_own_file" on storage.objects;
create policy "videos_delete_own_file" on storage.objects for delete to authenticated
  using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);
