// 部署前改成你自己的 Supabase 项目信息（Project Settings -> API）
// anon key 本来就是公开的，数据安全由数据库里的行级权限（RLS）保证
export const SUPABASE_URL = 'https://YOUR_PROJECT_ID.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR_ANON_PUBLIC_KEY';
// 单个视频的上传上限（MB）。Supabase 免费版单文件上限为 50MB，升级后可调大，
// 同时要改 schema.sql 里 bucket 的 file_size_limit
export const MAX_UPLOAD_MB = 50;
