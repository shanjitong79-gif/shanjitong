export const TRACE_IMAGES = [
  { key: "clouds", src: "/traces/clouds.jpg", label: "云海" },
  { key: "tea", src: "/traces/tea.jpg", label: "茶田" },
  { key: "alley", src: "/traces/alley.jpg", label: "雨巷" },
  { key: "bamboo", src: "/traces/bamboo.jpg", label: "竹径" },
  { key: "lake", src: "/traces/lake.jpg", label: "碧湖" },
  { key: "poplar", src: "/traces/poplar.jpg", label: "胡杨" },
  { key: "lantern", src: "/traces/lantern.jpg", label: "夜灯" },
  { key: "snow", src: "/traces/snow.jpg", label: "雪峰" },
  { key: "window", src: "/traces/window.jpg", label: "窗前" },
] as const;

export type ImageKey = (typeof TRACE_IMAGES)[number]["key"];

const KEYS = new Set<string>(TRACE_IMAGES.map((i) => i.key));

export function isImageKey(value: string | null | undefined): value is ImageKey {
  return Boolean(value && KEYS.has(value));
}

export function imageSrc(key: string | null | undefined): string | null {
  if (!isImageKey(key)) return null;
  return `/traces/${key}.jpg`;
}
