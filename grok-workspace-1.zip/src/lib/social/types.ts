export type Author = {
  userId: string;
  handle: string;
  displayName: string;
  hue: number;
};

export type PostItem = {
  id: number;
  body: string;
  imageKey: string | null;
  place: string;
  createdAt: string;
  author: Author;
  likeCount: number;
  commentCount: number;
  liked: boolean;
};

export type CommentItem = {
  id: number;
  body: string;
  createdAt: string;
  author: Author;
};

export type ProfilePublic = {
  userId: string;
  handle: string;
  displayName: string;
  bio: string;
  location: string;
  hue: number;
  createdAt: string;
  postCount: number;
  followerCount: number;
  followingCount: number;
  isMe: boolean;
  following: boolean;
};

export type PersonCard = {
  userId: string;
  handle: string;
  displayName: string;
  bio: string;
  location: string;
  hue: number;
  followerCount: number;
  following: boolean;
};

export type NoticeItem = {
  id: number;
  type: "like" | "comment" | "follow";
  read: boolean;
  createdAt: string;
  postId: number | null;
  actor: Author;
};
