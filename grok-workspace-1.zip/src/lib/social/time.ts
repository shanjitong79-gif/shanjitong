import { formatDistanceToNow } from "date-fns";
import { zhCN } from "date-fns/locale";

export function fromNow(isoString: string): string {
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return "";
  return formatDistanceToNow(d, { addSuffix: true, locale: zhCN });
}
