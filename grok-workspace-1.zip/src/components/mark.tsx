import { cn } from "@/lib/utils";

export function MountainMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-8", className)}
      aria-hidden
    >
      <rect width="32" height="32" rx="9" className="fill-pine" />
      <path
        d="M6 23.5 L12.4 12.2 L16 18.1 L19.8 10.5 L26 23.5 Z"
        className="fill-paper"
      />
      <path
        d="M6 23.5 H26"
        className="stroke-paper"
        strokeWidth="1.2"
        fill="none"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function UserMark({
  name,
  hue,
  size = "md",
}: {
  name: string;
  hue: number;
  size?: "sm" | "md" | "lg";
}) {
  const ch = (name.trim().charAt(0) || "山").toUpperCase();
  const dim =
    size === "sm" ? "size-8 text-sm" : size === "lg" ? "size-16 text-2xl" : "size-10 text-base";
  return (
    <span
      className={cn(
        "grid shrink-0 place-items-center rounded-full font-display font-medium",
        dim,
      )}
      style={{
        background: `hsl(${hue} 16% 28%)`,
        color: `hsl(${hue} 22% 92%)`,
      }}
      aria-hidden
    >
      {ch}
    </span>
  );
}
