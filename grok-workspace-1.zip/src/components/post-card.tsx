import { Link, useNavigate } from "@tanstack/react-router";
import { Heart, MapPin, MessageCircle, Trash2 } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { UserMark } from "@/components/mark";
import { imageSrc } from "@/lib/social/images";
import { deletePost, toggleLike } from "@/lib/social/fns";
import { fromNow } from "@/lib/social/time";
import type { PostItem } from "@/lib/social/types";
import { cn } from "@/lib/utils";
import { useCurrentUser } from "@/lib/auth/use-current-user";

export function PostCard({
  post,
  compact = false,
}: {
  post: PostItem;
  compact?: boolean;
}) {
  const user = useCurrentUser();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const src = imageSrc(post.imageKey);
  const isMine = Boolean(user && user.id === post.author.userId);

  const likeMut = useMutation({
    mutationFn: () => toggleLike({ data: { postId: post.id } }),
    onSuccess: () => {
      void qc.invalidateQueries();
    },
    onError: (err) => {
      if (err instanceof Error && err.message === "Unauthorized") {
        void navigate({ to: "/login" });
        return;
      }
      toast.error("没能记下这一赞");
    },
  });

  const delMut = useMutation({
    mutationFn: () => deletePost({ data: { id: post.id } }),
    onSuccess: () => {
      toast.success("已收回这段山迹");
      void qc.invalidateQueries();
    },
  });

  return (
    <article className="overflow-hidden rounded-xl border border-line bg-paper shadow-soft">
      {src && !compact && (
        <Link to="/p/$id" params={{ id: String(post.id) }} className="block">
          <img
            src={src}
            alt=""
            className="aspect-[3/2] w-full object-cover"
          />
        </Link>
      )}
      <div className={cn("p-4 sm:p-5", compact && "p-3")}>
        <div className="flex items-start gap-3">
          <Link to="/u/$handle" params={{ handle: post.author.handle }}>
            <UserMark name={post.author.displayName} hue={post.author.hue} />
          </Link>
          <div className="min-w-0 flex-1">
            <div className="flex items-baseline gap-2">
              <Link
                to="/u/$handle"
                params={{ handle: post.author.handle }}
                className="truncate font-medium text-ink hover:text-pine"
              >
                {post.author.displayName}
              </Link>
              <span className="truncate text-sm text-faint">
                @{post.author.handle}
              </span>
              <span className="ml-auto shrink-0 text-xs text-faint tabular-nums">
                {fromNow(post.createdAt)}
              </span>
            </div>
            <Link
              to="/p/$id"
              params={{ id: String(post.id) }}
              className="mt-2 block text-[15px] leading-relaxed text-ink-soft"
            >
              {post.body}
            </Link>
            {post.place ? (
              <p className="mt-2 flex items-center gap-1 text-xs text-muted">
                <MapPin className="size-3.5" strokeWidth={1.75} />
                {post.place}
              </p>
            ) : null}
            <div className="mt-3 flex items-center gap-1">
              <button
                type="button"
                onClick={() => likeMut.mutate()}
                className={cn(
                  "inline-flex h-10 items-center gap-1.5 rounded-[10px] px-2.5 text-sm transition-colors duration-150",
                  post.liked
                    ? "text-cinnabar"
                    : "text-muted hover:bg-paper-2 hover:text-ink",
                )}
                aria-pressed={post.liked}
              >
                <Heart
                  className="size-4"
                  strokeWidth={1.75}
                  fill={post.liked ? "currentColor" : "none"}
                />
                <span className="tabular-nums">{post.likeCount}</span>
              </button>
              <Link
                to="/p/$id"
                params={{ id: String(post.id) }}
                className="inline-flex h-10 items-center gap-1.5 rounded-[10px] px-2.5 text-sm text-muted transition-colors duration-150 hover:bg-paper-2 hover:text-ink"
              >
                <MessageCircle className="size-4" strokeWidth={1.75} />
                <span className="tabular-nums">{post.commentCount}</span>
              </Link>
              {isMine ? (
                <button
                  type="button"
                  onClick={() => delMut.mutate()}
                  className="ml-auto inline-flex size-10 items-center justify-center rounded-[10px] text-faint transition-colors duration-150 hover:bg-paper-2 hover:text-cinnabar"
                  aria-label="删除"
                >
                  <Trash2 className="size-4" strokeWidth={1.75} />
                </button>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </article>
  );
}

export function PostSkeleton() {
  return (
    <div className="overflow-hidden rounded-xl border border-line bg-paper">
      <div className="aspect-[3/2] animate-pulse bg-paper-3/80" />
      <div className="space-y-3 p-5">
        <div className="h-4 w-1/3 animate-pulse rounded bg-paper-3/80" />
        <div className="h-4 w-full animate-pulse rounded bg-paper-3/80" />
        <div className="h-4 w-2/3 animate-pulse rounded bg-paper-3/80" />
      </div>
    </div>
  );
}
