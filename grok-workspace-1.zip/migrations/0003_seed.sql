insert into profiles (user_id, handle, display_name, bio, location, hue, is_seed, created_at)
values
  ('seed-linwei',  'linwei',  '林微', '把云海当成日记写。黄山上下过无数次，仍会为同一片雾停留。', '杭州', 152, true, now() - interval '80 days'),
  ('seed-ayuan',   'ayuan',   '阿远', '川西公路的乘客。车坏了就等羊，天黑了就找锅。', '理塘', 28, true, now() - interval '70 days'),
  ('seed-suwan',   'suwan',   '苏晚', '在巷子里收集雨声。茶凉了再续一壶。', '苏州', 198, true, now() - interval '62 days'),
  ('seed-beishan', 'beishan', '北山', '秦岭北麓的植物观察者。不赶路，只记光线。', '西安', 118, true, now() - interval '55 days'),
  ('seed-jiang',   'jiang',   '江澄', '夜色湿润的人。江面比镜子诚实。', '重庆', 8, true, now() - interval '48 days'),
  ('seed-guqing',  'guqing',  '顾青', '风比人话多的地方，我坐得住。', '大理', 168, true, now() - interval '40 days'),
  ('seed-muzi',    'muzi',    '木子', '靠海的下午适合发呆。墙皮剥落也是笔迹。', '厦门', 210, true, now() - interval '32 days'),
  ('seed-shenye',  'shenye',  '沈野', '把风声当成伴奏。沙漠里的金不是金子的金。', '额济纳', 38, true, now() - interval '24 days')
on conflict (user_id) do nothing;

insert into posts (user_id, body, image_key, place, created_at)
select * from (values
  ('seed-linwei',  '凌晨四点上山，云海比预想的安静。风从脚底穿过，整座山像在呼吸。有人问值不值得起这么早——值。因为这份静，白天是买不到的。', 'clouds'::text, '黄山 · 光明顶', now() - interval '18 hours'),
  ('seed-ayuan',   '川西的路总是比地图长。停车等羊群过完，天已经从灰蓝变成这种颜色。油箱还够，心情也够。', null::text, '理塘东路', now() - interval '1 day 4 hours'),
  ('seed-suwan',   '雨后的巷子会把脚步声还给我。苏州不急，茶也不急。门开了一条缝，里面是旧木的味道。', 'alley', '苏州 · 平江路', now() - interval '2 days'),
  ('seed-beishan', '秦岭北麓的竹林里几乎没有风。光线一缕一缕落下来，像被谁仔细分过。我走得很慢，怕踩乱这份秩序。', 'bamboo', '秦岭', now() - interval '2 days 8 hours'),
  ('seed-jiang',   '重庆的夜是湿的。江面把楼灯揉碎，再拼回去。我在桥上看了很久，伞忘在了上一站。', 'lantern', '重庆 · 南滨路', now() - interval '3 days'),
  ('seed-guqing',  '洱海边风很大，风铃比人话多。我在苍山下坐了很久，什么也没拍好，倒是把心拍静了。', 'lake', '大理 · 喜洲', now() - interval '4 days'),
  ('seed-muzi',    '厦门的午后适合发呆。窗开着，茶还热，山在格子门外变淡。今天没有行程，这很好。', 'window', '厦门 · 鼓浪屿', now() - interval '5 days'),
  ('seed-shenye',  '胡杨的金不是金子的金。是干透了的、被风磨过的那种亮。站在树下会觉得时间也变得很薄。', 'poplar', '额济纳', now() - interval '6 days'),
  ('seed-linwei',  '茶田在雾里一垄一垄地醒。摘茶的人还没上山，只有露水在叶子上开会。我想起去年也是这个时辰。', 'tea', '杭州 · 龙井', now() - interval '7 days'),
  ('seed-guqing',  '雪峰把湖面当成镜子。靠近岸边的冰薄得像一层呼吸。没有人，连鸟也很少。这样的空，值得专程来一趟。', 'snow', '玉龙旁的无名湖', now() - interval '8 days'),
  ('seed-beishan', '有些路不需要目的地。走着走着，光线自己会把方向告诉你。今天只记下这一句。', null::text, '终南山', now() - interval '9 days'),
  ('seed-suwan',   '把一杯茶放凉，再续热的。生活里很多事，其实只需这个节奏。', 'window', '苏州 · 山塘', now() - interval '10 days'),
  ('seed-ayuan',   '车灯扫过一排杨树。收音机里只有沙沙声。我把窗户降下一半，让风把白天的灰吹走。', 'poplar', '雀儿山以西', now() - interval '11 days'),
  ('seed-muzi',    '海在屋瓦下面。从崖边小路望下去，船小得像被谁随手搁在银纸上。风咸，心倒是淡的。', 'lake', '厦门 · 曾厝垵', now() - interval '12 days')
) as seed(user_id, body, image_key, place, created_at)
where not exists (select 1 from posts);

insert into likes (post_id, user_id, created_at)
select p.id, v.user_id, now() - (v.n || ' hours')::interval
from posts p
cross join (values
  ('seed-ayuan', 3),
  ('seed-suwan', 5),
  ('seed-beishan', 8),
  ('seed-jiang', 2),
  ('seed-guqing', 12),
  ('seed-muzi', 7),
  ('seed-shenye', 4),
  ('seed-linwei', 9)
) as v(user_id, n)
where v.user_id <> p.user_id
  and (p.id + v.n) % 3 <> 0
on conflict do nothing;

insert into comments (post_id, user_id, body, created_at)
select p.id, c.user_id, c.body, now() - (c.n || ' hours')::interval
from posts p
join (values
  ('clouds', 'seed-guqing', '这份静，我在苍山也遇见过。', 6),
  ('clouds', 'seed-beishan', '早起是对山的礼貌。', 5),
  ('alley', 'seed-linwei', '门缝里的旧木味，一下子就回去了。', 20),
  ('bamboo', 'seed-suwan', '光线被仔细分过——这句太准了。', 30),
  ('lantern', 'seed-muzi', '湿的夜最动人。厦门的海风也这样。', 40),
  ('lake', 'seed-linwei', '没拍好也没关系，心静了就是成片。', 50),
  ('tea', 'seed-shenye', '露水开会，这个说法我要借走。', 70),
  ('snow', 'seed-ayuan', '专程去赴一场空，值得。', 80),
  ('window', 'seed-jiang', '没有行程的日子，才像自己的。', 55)
) as c(image_key, user_id, body, n)
where p.image_key = c.image_key
  and p.user_id <> c.user_id
  and not exists (select 1 from comments);

insert into follows (follower_id, followee_id, created_at)
values
  ('seed-linwei', 'seed-beishan', now() - interval '20 days'),
  ('seed-linwei', 'seed-suwan', now() - interval '18 days'),
  ('seed-ayuan', 'seed-linwei', now() - interval '16 days'),
  ('seed-ayuan', 'seed-shenye', now() - interval '15 days'),
  ('seed-suwan', 'seed-linwei', now() - interval '14 days'),
  ('seed-suwan', 'seed-muzi', now() - interval '13 days'),
  ('seed-beishan', 'seed-linwei', now() - interval '12 days'),
  ('seed-beishan', 'seed-guqing', now() - interval '11 days'),
  ('seed-jiang', 'seed-muzi', now() - interval '10 days'),
  ('seed-jiang', 'seed-linwei', now() - interval '9 days'),
  ('seed-guqing', 'seed-linwei', now() - interval '8 days'),
  ('seed-guqing', 'seed-ayuan', now() - interval '7 days'),
  ('seed-muzi', 'seed-suwan', now() - interval '6 days'),
  ('seed-muzi', 'seed-jiang', now() - interval '5 days'),
  ('seed-shenye', 'seed-ayuan', now() - interval '4 days'),
  ('seed-shenye', 'seed-guqing', now() - interval '3 days')
on conflict do nothing;
