#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "请先运行: pkg install nodejs"
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "首次运行，正在安装依赖..."
  npm install
fi
echo ""
echo "================================"
echo " shanjitong 手机 CMS"
echo " 网站: http://127.0.0.1:3000/"
echo " 后台: http://127.0.0.1:3000/admin.html"
echo "================================"
npm start
