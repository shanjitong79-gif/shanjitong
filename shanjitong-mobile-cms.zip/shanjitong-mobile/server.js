const express=require("express");
const session=require("express-session");
const Database=require("better-sqlite3");
const path=require("path");
const crypto=require("crypto");

const app=express();
const PORT=process.env.PORT||3000;
const ADMIN_USER=process.env.ADMIN_USER||"admin";
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||"ChangeMe_123!";
const SESSION_SECRET=process.env.SESSION_SECRET||crypto.randomBytes(32).toString("hex");

const db=new Database(path.join(__dirname,"news.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS news(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 summary TEXT NOT NULL DEFAULT '',
 content TEXT NOT NULL DEFAULT '',
 cover TEXT NOT NULL DEFAULT '',
 author TEXT NOT NULL DEFAULT 'shanjitong',
 status TEXT NOT NULL DEFAULT 'draft',
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 published_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_news_status_date ON news(status,published_at);
`);

const count=db.prepare("SELECT COUNT(*) c FROM news").get().c;
if(!count){
 const now=new Date().toISOString();
 const insert=db.prepare(`INSERT INTO news(title,summary,content,cover,author,status,created_at,updated_at,published_at)
 VALUES(?,?,?,?,?,?,?,?,?)`);
 insert.run("shanjitong OS 2.0 正式上线","全新的 Windows 风格企业数字空间正式发布。","shanjitong OS 2.0 将企业介绍、服务、项目、新闻和联系中心统一到一个现代化数字空间。","","shanjitong","published",now,now,now);
}

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(session({
 secret:SESSION_SECRET,
 resave:false,
 saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}
}));
app.use(express.static(path.join(__dirname,"public")));

function auth(req,res,next){ if(req.session.admin) return next(); res.status(401).json({error:"未登录"}); }
function clean(v){return String(v??"").trim()}
function validate(body){
 const title=clean(body.title), summary=clean(body.summary), content=clean(body.content);
 if(!title||!summary||!content) return "标题、摘要和正文不能为空";
 if(title.length>120||summary.length>500||content.length>30000) return "内容长度超出限制";
 return null;
}

app.get("/api/news", (req,res)=>{
 const rows=db.prepare(`SELECT id,title,summary,cover,author,published_at,created_at,updated_at
 FROM news WHERE status='published' ORDER BY datetime(published_at) DESC`).all();
 res.json(rows);
});
app.get("/api/news/:id",(req,res)=>{
 const row=db.prepare(`SELECT id,title,summary,content,cover,author,published_at,created_at,updated_at,status
 FROM news WHERE id=? AND status='published'`).get(Number(req.params.id));
 if(!row) return res.status(404).json({error:"新闻不存在"});
 res.json(row);
});

app.post("/api/login",(req,res)=>{
 const u=clean(req.body.username), p=String(req.body.password||"");
 if(u===ADMIN_USER && p===ADMIN_PASSWORD){req.session.admin=true;return res.json({ok:true})}
 res.status(401).json({error:"账号或密码错误"});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json({admin:!!req.session.admin}));

app.get("/api/admin/news",auth,(req,res)=>{
 res.json(db.prepare("SELECT * FROM news ORDER BY datetime(created_at) DESC").all());
});
app.post("/api/admin/news",auth,(req,res)=>{
 const err=validate(req.body); if(err) return res.status(400).json({error:err});
 const title=clean(req.body.title),summary=clean(req.body.summary),content=clean(req.body.content);
 const cover=clean(req.body.cover),author=clean(req.body.author)||"shanjitong";
 const status=req.body.status==="published"?"published":"draft", now=new Date().toISOString();
 const published=status==="published"?now:null;
 const info=db.prepare(`INSERT INTO news(title,summary,content,cover,author,status,created_at,updated_at,published_at)
 VALUES(?,?,?,?,?,?,?,?,?)`).run(title,summary,content,cover,author,status,now,now,published);
 res.json({ok:true,id:info.lastInsertRowid});
});
app.put("/api/admin/news/:id",auth,(req,res)=>{
 const err=validate(req.body); if(err) return res.status(400).json({error:err});
 const id=Number(req.params.id), old=db.prepare("SELECT * FROM news WHERE id=?").get(id);
 if(!old) return res.status(404).json({error:"新闻不存在"});
 const status=req.body.status==="published"?"published":"draft";
 const published=status==="published"?(old.published_at||new Date().toISOString()):null;
 db.prepare(`UPDATE news SET title=?,summary=?,content=?,cover=?,author=?,status=?,updated_at=?,published_at=? WHERE id=?`)
 .run(clean(req.body.title),clean(req.body.summary),clean(req.body.content),clean(req.body.cover),
      clean(req.body.author)||"shanjitong",status,new Date().toISOString(),published,id);
 res.json({ok:true});
});
app.delete("/api/admin/news/:id",auth,(req,res)=>{
 const info=db.prepare("DELETE FROM news WHERE id=?").run(Number(req.params.id));
 if(!info.changes) return res.status(404).json({error:"新闻不存在"});
 res.json({ok:true});
});

app.listen(PORT,"0.0.0.0",()=>console.log(`shanjitong CMS running: http://0.0.0.0:${PORT}`));
