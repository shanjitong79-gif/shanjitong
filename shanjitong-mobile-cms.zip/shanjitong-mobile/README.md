# shanjitong Mobile CMS

这是为 Android 手机部署优化的 shanjitong 企业新闻 CMS。

## 核心
- Node.js + Express
- SQLite 持久化
- 手机优先后台界面
- 新闻发布 / 编辑 / 删除 / 草稿
- 前台新闻自动更新
- 局域网访问
- Termux 启动脚本

完整手机步骤见：`手机部署指南.md`

默认管理员：
`admin / ChangeMe_123!`

正式使用前请修改密码和 SESSION_SECRET。
